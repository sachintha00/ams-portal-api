<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{

    public function up(): void
    {
        Schema::create('dashboard_item_related_sub_item', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('dashboard_item_id');
            $table->string('widget_icon_folder_path');
            $table->string('widget_item_x_position');
            $table->string('widget_item_y_position');
            $table->string('widget_item_width');
            $table->string('widget_item_height');
            $table->string('widget_item_design_code');
            $table->timestamps();

            
            $table->foreign('dashboard_item_id')->references('id')->on('dashboard_item')->onDelete('cascade');
        });
    }


    public function down(): void
    {
        Schema::table('dashboard_item_related_sub_item', function (Blueprint $table) {
            $table->dropForeign(['dashboard_item_id']);
        });
    
        Schema::dropIfExists('dashboard_item_related_sub_item');
    }
};